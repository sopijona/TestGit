var pht1 = document.querySelector("img");
function showPht1(){
    pht1.style.marginLeft="0";
}
var pht2 = document.querySelector("img");
function showPht2(){
    pht2.style.marginLeft="-25%";
}
var pht3 = document.querySelector("img");
function showPht3(){
    pht3.style.marginLeft="-50%";
}
var pht4 = document.querySelector("img");
function showPht4(){
    pht4.style.marginLeft="-75%";
}
var pht5 = document.querySelector("img");
function showPht5(){
    pht5.style.marginLeft="-100%";
}
var pht6 = document.querySelector("img");
function showPht6(){
    pht6.style.marginLeft="-125%";
}





